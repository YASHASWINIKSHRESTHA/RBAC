
import React from "react";
import UserManagement from "./components/UserManagement";
import RoleManagement from "./components/RoleManagement";
import { UserProvider } from "./context/UserContext";
import { RoleProvider } from "./context/RoleContext";

const App = () => (
  <UserProvider>
    <RoleProvider>
      <div>
        <h1>RBAC Management</h1>
        <UserManagement />
        <RoleManagement />
      </div>
    </RoleProvider>
  </UserProvider>
);

export default App;
        