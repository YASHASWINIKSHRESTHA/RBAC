
import React, { createContext, useState } from "react";

export const UserContext = createContext();

export const UserProvider = ({ children }) => {
  const [users, setUsers] = useState([]);

  const addUser = (user) => setUsers([...users, { id: Date.now(), ...user }]);
  const editUser = (id) => {
    // Edit logic
  };
  const deleteUser = (id) => setUsers(users.filter((user) => user.id !== id));

  return (
    <UserContext.Provider value={{ users, addUser, editUser, deleteUser }}>
      {children}
    </UserContext.Provider>
  );
};
            