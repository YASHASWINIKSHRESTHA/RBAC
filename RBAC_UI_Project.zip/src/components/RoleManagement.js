
import React, { useContext, useState } from "react";
import { RoleContext } from "../context/RoleContext";
import { Button, Modal, Table, TextField } from "@mui/material";

const RoleManagement = () => {
  const { roles, addRole, editRole, deleteRole } = useContext(RoleContext);
  const [open, setOpen] = useState(false);
  const [selectedRole, setSelectedRole] = useState(null);

  const handleOpen = (role = null) => {
    setSelectedRole(role);
    setOpen(true);
  };

  const handleClose = () => setOpen(false);

  return (
    <div>
      <h2>Role Management</h2>
      <Button variant="contained" color="primary" onClick={() => handleOpen()}>
        Add Role
      </Button>
      <Table>
        <thead>
          <tr>
            <th>Role</th>
            <th>Permissions</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {roles.map((role) => (
            <tr key={role.id}>
              <td>{role.name}</td>
              <td>{role.permissions.join(", ")}</td>
              <td>
                <Button onClick={() => handleOpen(role)}>Edit</Button>
                <Button color="error" onClick={() => deleteRole(role.id)}>
                  Delete
                </Button>
              </td>
            </tr>
          ))}
        </tbody>
      </Table>

      {/* Modal for Add/Edit */}
      <Modal open={open} onClose={handleClose}>
        <div style={{ padding: 20 }}>
          <h3>{selectedRole ? "Edit Role" : "Add Role"}</h3>
          <TextField
            label="Role Name"
            defaultValue={selectedRole?.name || ""}
            fullWidth
            margin="normal"
          />
          <Button
            variant="contained"
            color="primary"
            onClick={() =>
              selectedRole
                ? editRole(selectedRole.id)
                : addRole({ name: "New Role" })
            }
          >
            {selectedRole ? "Save" : "Add"}
          </Button>
        </div>
      </Modal>
    </div>
  );
};

export default RoleManagement;
            