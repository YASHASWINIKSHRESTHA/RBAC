
import React, { useContext, useState } from "react";
import { UserContext } from "../context/UserContext";
import { Button, Modal, Table, TextField } from "@mui/material";

const UserManagement = () => {
  const { users, addUser, editUser, deleteUser } = useContext(UserContext);
  const [open, setOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState(null);

  const handleOpen = (user = null) => {
    setSelectedUser(user);
    setOpen(true);
  };

  const handleClose = () => setOpen(false);

  return (
    <div>
      <h2>User Management</h2>
      <Button variant="contained" color="primary" onClick={() => handleOpen()}>
        Add User
      </Button>
      <Table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Role</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {users.map((user) => (
            <tr key={user.id}>
              <td>{user.name}</td>
              <td>{user.email}</td>
              <td>{user.role}</td>
              <td>
                <Button onClick={() => handleOpen(user)}>Edit</Button>
                <Button color="error" onClick={() => deleteUser(user.id)}>
                  Delete
                </Button>
              </td>
            </tr>
          ))}
        </tbody>
      </Table>

      {/* Modal for Add/Edit */}
      <Modal open={open} onClose={handleClose}>
        <div style={{ padding: 20 }}>
          <h3>{selectedUser ? "Edit User" : "Add User"}</h3>
          <TextField
            label="Name"
            defaultValue={selectedUser?.name || ""}
            fullWidth
            margin="normal"
          />
          <TextField
            label="Email"
            defaultValue={selectedUser?.email || ""}
            fullWidth
            margin="normal"
          />
          <Button
            variant="contained"
            color="primary"
            onClick={() =>
              selectedUser
                ? editUser(selectedUser.id)
                : addUser({ name: "New User" })
            }
          >
            {selectedUser ? "Save" : "Add"}
          </Button>
        </div>
      </Modal>
    </div>
  );
};

export default UserManagement;
            